#pragma once
#include "ofxBox2dBaseShape.h"

class ofxBox2dLoop: public ofxBox2dBaseShape {
private:
    vector <ofPoint> vertices;
    b2Vec2* m_vertices;
public:
    ofxBox2dLoop();
    //~ofxBox2dLoop();

 	bool createShape(b2World* world, bool staticBody = false);
	void clear();

 	void addVertex(float x, float y);

 	void draw();
protected:

};
