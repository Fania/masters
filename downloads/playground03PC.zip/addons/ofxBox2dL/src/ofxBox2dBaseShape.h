#pragma once
#include <Box2D\Box2D.h>
#include "ofxBox2dUtils.h"
#include "ofMain.h"

class ofxBox2dBaseShape {
public:
	ofxBox2dBaseShape();
	~ofxBox2dBaseShape();

	virtual void destroyShape();

	void setColour(unsigned int hexColour);
	void setColour(int r, int g, int b, int a = 255);
protected:
	b2World* m_world;
    b2Body* m_body;

    int a;
    int r;
    int g;
    int b;
};
