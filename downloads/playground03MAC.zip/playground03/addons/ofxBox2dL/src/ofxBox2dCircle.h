#pragma once
#include "ofxBox2dBaseShape.h"

class ofxBox2dCircle: public ofxBox2dBaseShape {
private:
    float   m_radius;
public:
    //ofxBox2dCircle();
    //~ofxBox2dCircle();

 	void createShape(b2World* world, float x, float y, float radius, bool staticBody = false);
 	//void destroyShape();

 	float getRadius();
 	b2Vec2 getPosition();

 	virtual void draw();
protected:

};
