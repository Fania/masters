#pragma once
#include <Box2D/Box2D.h>

// Pixels per meter
#define OFX_BOX2D_SCALE 30.0f
