#ifndef OFX_CV_H
#define OFX_CV_H


//--------------------------
// constants
#include "ofxCvConstants.h"

//--------------------------
// images
#include "ofxCvImage.h"
#include "ofxCvGrayscaleImage.h"
#include "ofxCvColorImage.h"
#include "ofxCvFloatImage.h"
#include "ofxCvShortImage.h"

#include "ofxCvContourFinder.h"
/*
//--------------------------
// contours and blobs

#include "ofxCvBlobTracker.h" ////////////
#include "ofxCvBlob.h" ///////////////////
#include "ofxCvConstants_Track.h" ////////
#include "ofxCvTrackedBlob.h" ////////////
*/

#endif
